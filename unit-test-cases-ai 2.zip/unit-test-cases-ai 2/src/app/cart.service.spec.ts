import { TestBed } from '@angular/core/testing';
import { CartService } from './cart.service';

describe('CartService', () => {
  let service: CartService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CartService);
  });

  it('should start empty with zero total', () => {
    expect(service.items()).toEqual([]);
    expect(service.total()).toBe(0);
  });

  it('should add a new item and compute total', () => {
    service.add({ id: 'a', price: 10, quantity: 2 });
    expect(service.items().length).toBe(1);
    expect(service.total()).toBe(20);
  });

  it('should merge quantity when adding an existing id', () => {
    service.add({ id: 'a', price: 10, quantity: 1 });
    service.add({ id: 'a', price: 10, quantity: 2 });
    expect(service.items()).toEqual([{ id: 'a', price: 10, quantity: 3 }]);
    expect(service.total()).toBe(30);
  });

  it('should not mutate the object passed in', () => {
    const item = { id: 'a', price: 5, quantity: 1 };
    service.add(item);
    service.add({ id: 'a', price: 5, quantity: 1 });
    expect(item.quantity).toBe(1);
  });

  it('should accept a zero price (boundary)', () => {
    service.add({ id: 'free', price: 0, quantity: 1 });
    expect(service.total()).toBe(0);
  });

  it.each([
    ['zero quantity', { id: 'a', price: 1, quantity: 0 }],
    ['negative quantity', { id: 'a', price: 1, quantity: -1 }],
    ['negative price', { id: 'a', price: -1, quantity: 1 }],
    ['null item', null],
    ['undefined item', undefined],
  ])('should throw for %s', (_name, input) => {
    expect(() => service.add(input as never)).toThrowError('Invalid cart item');
    expect(service.items()).toEqual([]);
  });

  it('should remove an item by id', () => {
    service.add({ id: 'a', price: 1, quantity: 1 });
    service.add({ id: 'b', price: 2, quantity: 1 });
    service.remove('a');
    expect(service.items().map((i) => i.id)).toEqual(['b']);
  });

  it('should ignore removal of an unknown id', () => {
    service.add({ id: 'a', price: 1, quantity: 1 });
    service.remove('zzz');
    expect(service.items().length).toBe(1);
  });

  it('should clear all items', () => {
    service.add({ id: 'a', price: 1, quantity: 1 });
    service.clear();
    expect(service.items()).toEqual([]);
    expect(service.total()).toBe(0);
  });
});
