import { Injectable, signal, computed } from '@angular/core';

export interface CartItem {
  id: string;
  price: number;
  quantity: number;
}

@Injectable({ providedIn: 'root' })
export class CartService {
  private readonly _items = signal<CartItem[]>([]);

  readonly items = this._items.asReadonly();
  readonly total = computed(() =>
    this._items().reduce((sum, i) => sum + i.price * i.quantity, 0),
  );

  add(item: CartItem): void {
    if (!item || item.quantity <= 0 || item.price < 0) {
      throw new Error('Invalid cart item');
    }
    const existing = this._items().find((i) => i.id === item.id);
    if (existing) {
      this._items.update((list) =>
        list.map((i) => (i.id === item.id ? { ...i, quantity: i.quantity + item.quantity } : i)),
      );
    } else {
      this._items.update((list) => [...list, { ...item }]);
    }
  }

  remove(id: string): void {
    this._items.update((list) => list.filter((i) => i.id !== id));
  }

  clear(): void {
    this._items.set([]);
  }
}
